#pragma once
#ifdef LET18MAXSUBSTRBORODIN_EXPORTS
#define LET18MAXSUBSTRBORODIN_API __declspec(dllexport)
#else
#define LET18MAXSUBSTRBORODIN_API __declspec(dllimport)
#endif