#pragma once
#ifdef PZ18TRIGRAMBORODIN_EXPORTS
#define PZ18TRIGRAMBORODIN_API __declspec(dllexport)
#else
#define PZ18TRIGRAMBORODIN_API __declspec(dllimport)
#endif