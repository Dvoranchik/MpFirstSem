#pragma once
#ifdef LET17TRIGRAMBORODIN_EXPORTS
#define LET17TRIGRAMBORODIN_API __declspec(dllexport)
#else
#define LET17TRIGRAMBORODIN_API __declspec(dllimport)
#endif