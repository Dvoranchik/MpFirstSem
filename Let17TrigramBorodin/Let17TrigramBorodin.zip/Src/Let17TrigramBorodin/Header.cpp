#include "stdafx.h"
#include "Header.h"

int sum()
{
	return 5;
}
